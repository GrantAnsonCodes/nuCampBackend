module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl': 'mongodb://localhost:27017/nucampsite',
    'facebook': {
        clientId: '1164099067507531',
        clientSecret: '2faee1530d1310c9e970614a8e9c8fe7'
    }
}